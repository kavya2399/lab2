package com.capg.lab2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.lab2.model.Trainee;

public interface TraineeRepository extends JpaRepository<Trainee,Integer> {

}
