package com.capg.lab2.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainee")
public class Trainee {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="traineeid")
 private Integer traineeId;
	@Column(name="traineename")
 private String traineeName;
	@Column(name="domain")
 private String domain;
	@Column(name="location")
 private String location;
public Integer getTraineeId() {
	return traineeId;
}
public void setTraineeId(Integer traineeId) {
	this.traineeId = traineeId;
}
public String getTraineeName() {
	return traineeName;
}
public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
 
}
