package com.capg.lab2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.lab2.model.Trainee;
import com.capg.lab2.service.TraineeService;
@Controller
public class TraineeController {
	@Autowired
TraineeService service;

	
	@RequestMapping("/login")
	public String getlogin() {
		return "login";
	}
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView getHome() {
		ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("home");
		  return mav; 
	}
	@RequestMapping(value="/add", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
	  
	  
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("add");
		  mav.addObject("trainee", new Trainee()); 
		  return mav; 
	  }
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("trainee") Trainee trainee) {
		
		service.addTrainee(trainee);
		ModelAndView mav = new ModelAndView("add");
		String message = "Trainee details Added Successfully with traineeid "+trainee.getTraineeId();
		mav.addObject("successMessage", message);
		return mav;
	}
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public ModelAndView loaddeleteTrainee() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("delete");
		
		return mav;
	}
	@RequestMapping(value="/delete" ,method=RequestMethod.POST)
	public ModelAndView deleteTrainee(@RequestParam Integer traineeId ){
		Trainee e= service.findTrainee(traineeId);
		ModelAndView mav=new ModelAndView();
		mav.setViewName("delete");
		if(e!=null) {
			service.removeTrainee(traineeId);	
			  String msg="Trainee deleted ";
			     mav.addObject("successmsg",msg);	
		}
		else {
			  String msg="Trainee not found";
			     mav.addObject("errormsg",msg);	
		}
		return mav;
	
	}
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public ModelAndView loadupdateTrainee() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("update");
		mav.addObject("trainee",new Trainee());
		return mav;
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView updateTrainee(@ModelAttribute("trainee") Trainee trainee) {
		service.updateTrainee(trainee);
		System.out.println("found="+trainee);
		String message="trainee updated Successfully with traineed"+trainee.getTraineeId();
		ModelAndView mav=new ModelAndView("update");
		mav.addObject("successMsg",message);
		return mav;
		
	}
	@RequestMapping(value="/retrive", method=RequestMethod.GET)
	public ModelAndView loadGetTraineeById() {			
		ModelAndView mav = new ModelAndView("retrive");		
		return mav;
	}
	
	@RequestMapping(value="/retrive", method=RequestMethod.POST)
	public ModelAndView getTraineeById(@RequestParam Integer traineeId) {
		Trainee t= service.findTrainee(traineeId);
		System.out.println("found = "+t);
		ModelAndView mav = new ModelAndView("retrive");	
		if(t!=null) {
			mav.addObject("trainee", t);
		}
		else
			mav.addObject("errorMessage","Employee details not found for the given employee id");
		
		return mav;
	}
	@RequestMapping(value="/retriveall", method=RequestMethod.GET)
	public ModelAndView getEmloyees() {
		List<Trainee> list = service.getTrainee();
		ModelAndView mav = new ModelAndView("retriveall");
		if(list.isEmpty()) {
			mav.addObject("errorMessage", "Trainee details not found");			
		}
		else {
			mav.addObject("traineeList",list);			
		}
		
		return mav;
	}

}

